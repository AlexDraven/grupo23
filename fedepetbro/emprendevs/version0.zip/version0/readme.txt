Instrucciones

instalar en xamp o similar,
base de datos mysql emprendevs

configuracion de db en comun.php

esta version solo de prueba de modelo de datos.

EmprenDevs, Rosario, Argentina




