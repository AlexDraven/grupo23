<?php
echo" 
<a href='index.php'>Home</a> -
<a href='prestadores.php'>Prestadores</a> -
<a href='usuarios.php'>Usuarios</a> -
<a href='publicaciones.php'>Publicaciones</a> -
<a href='mapa.php'>Mapa</a> -
<hr>";
?>