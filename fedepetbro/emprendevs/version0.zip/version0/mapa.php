
<?php
include ("comun.php");
include ("menu.php");
echo "<iframe src='_mapa.php' height='600px' width='1024px'></iframe>";
?>